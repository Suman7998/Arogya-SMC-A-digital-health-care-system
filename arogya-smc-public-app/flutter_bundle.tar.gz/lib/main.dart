// lib/main.dart
//
// Arogya SMC Citizen App
// Solapur Municipal Corporation – Digital Health Platform
//
// Entry point: ProviderScope + Hive init + GoRouter

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'core/constants/app_constants.dart';
import 'core/theme/app_theme.dart';
import 'navigation/app_router.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Lock orientation to portrait
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // Configure status bar style
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
    ),
  );

  // Initialize Hive
  await Hive.initFlutter();
  await Hive.openBox(AppConstants.hospitalsBox);
  await Hive.openBox(AppConstants.settingsBox);

  runApp(
    const ProviderScope(
      child: ArogyaSMCApp(),
    ),
  );
}

class ArogyaSMCApp extends StatelessWidget {
  const ArogyaSMCApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: AppConstants.appName,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      routerConfig: goRouter,
    );
  }
}