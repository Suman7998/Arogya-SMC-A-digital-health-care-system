// lib/providers/alert_provider.dart

import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/models/alert_model.dart';
import '../data/models/advisory_model.dart';
import '../data/repositories/alert_repository.dart';

final alertRepositoryProvider = Provider<AlertRepository>((ref) {
  return AlertRepository();
});

// All alerts async provider
final alertListProvider =
    AsyncNotifierProvider<AlertNotifier, List<AlertModel>>(
  AlertNotifier.new,
);

class AlertNotifier extends AsyncNotifier<List<AlertModel>> {
  @override
  Future<List<AlertModel>> build() async {
    final repo = ref.read(alertRepositoryProvider);
    return repo.getAlerts();
  }
}

// Selected filter type (null = All)
final alertFilterProvider = StateProvider<AlertType?>((ref) => null);

// Filtered alerts
final filteredAlertsProvider = Provider<AsyncValue<List<AlertModel>>>((ref) {
  final filter = ref.watch(alertFilterProvider);
  final alertsAsync = ref.watch(alertListProvider);
  return alertsAsync.whenData(
    (alerts) => filter == null
        ? alerts
        : alerts.where((a) => a.type == filter).toList(),
  );
});

// Advisories provider for home screen carousel
final advisoriesProvider =
    FutureProvider<List<AdvisoryModel>>((ref) async {
  final repo = ref.read(alertRepositoryProvider);
  return repo.getAdvisories();
});
