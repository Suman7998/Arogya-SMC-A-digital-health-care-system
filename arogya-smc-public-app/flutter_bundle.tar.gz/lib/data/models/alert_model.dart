// lib/data/models/alert_model.dart

enum AlertType { flu, dengue, vaccination, general }

enum AlertSeverity { low, medium, high }

class AlertModel {
  final String id;
  final String title;
  final String description;
  final AlertType type;
  final AlertSeverity severity;
  final DateTime date;
  final String issuedBy;

  const AlertModel({
    required this.id,
    required this.title,
    required this.description,
    required this.type,
    required this.severity,
    required this.date,
    required this.issuedBy,
  });

  factory AlertModel.fromJson(Map<String, dynamic> json) => AlertModel(
        id: (json['id'] ?? json['_id'] ?? '').toString(),
        title: (json['title'] ?? 'Health Alert').toString(),
        description: (json['description'] ?? json['content'] ?? '').toString(),
        type: AlertType.values.firstWhere(
          (e) => e.name == (json['type'] as String? ?? ''),
          orElse: () => AlertType.general,
        ),
        severity: AlertSeverity.values.firstWhere(
          (e) => e.name == (json['severity'] as String? ?? ''),
          orElse: () => AlertSeverity.low,
        ),
        date: json['date'] != null
            ? DateTime.tryParse(json['date'].toString()) ?? DateTime.now()
            : DateTime.now(),
        issuedBy: (json['issued_by'] ?? json['issuedBy'] ?? '').toString(),
      );
}
