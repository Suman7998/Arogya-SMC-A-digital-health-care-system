// lib/data/models/advisory_model.dart

class AdvisoryModel {
  final String id;
  final String title;
  final String description;
  final String issuedBy;
  final String? date;
  final String? category;

  const AdvisoryModel({
    required this.id,
    required this.title,
    required this.description,
    required this.issuedBy,
    this.date,
    this.category,
  });

  factory AdvisoryModel.fromJson(Map<String, dynamic> json) => AdvisoryModel(
        id: (json['id'] ?? json['_id'] ?? '').toString(),
        title: (json['title'] ?? 'Advisory').toString(),
        description: (json['description'] ?? json['content'] ?? '').toString(),
        issuedBy: (json['issued_by'] ?? json['issuedBy'] ?? 'SMC').toString(),
        date: json['date']?.toString() ?? json['createdAt']?.toString(),
        category: json['category']?.toString() ?? json['type']?.toString(),
      );
}
