// lib/data/repositories/alert_repository.dart

import '../models/alert_model.dart';
import '../models/advisory_model.dart';
import '../services/api_service.dart';

class AlertRepository {
  final ApiService _apiService;

  AlertRepository({ApiService? apiService})
      : _apiService = apiService ?? ApiService();

  Future<List<AlertModel>> getAlerts() async {
    return _apiService.fetchAlerts();
  }

  Future<List<AdvisoryModel>> getAdvisories() async {
    return _apiService.fetchAdvisories();
  }
}
