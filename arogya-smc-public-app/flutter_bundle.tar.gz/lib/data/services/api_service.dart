// lib/data/services/api_service.dart
//
// Real API Service using the `http` package.
// Base URL: http://10.0.2.2:3000/api/public (Android emulator → host machine)

import 'dart:convert';
import 'package:http/http.dart' as http;
import '../../core/constants/app_constants.dart';
import '../models/hospital_model.dart';
import '../models/alert_model.dart';
import '../models/advisory_model.dart';
import '../models/ward_model.dart';

class ApiService {
  static final Uri _base = Uri.parse(AppConstants.apiBaseUrl);

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------

  /// Generic GET → JSON list decoder.
  Future<List<Map<String, dynamic>>> _getList(String endpoint) async {
    final url = _base.replace(path: _base.path + endpoint);
    late http.Response response;
    try {
      response = await http.get(url).timeout(const Duration(seconds: 15));
    } catch (e) {
      throw Exception('Network error: $e');
    }

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Server error ${response.statusCode} for $endpoint');
    }

    final decoded = jsonDecode(response.body);

    // Backend may return either a plain list or a wrapper: { "data": [...] }
    if (decoded is List) {
      return decoded.cast<Map<String, dynamic>>();
    } else if (decoded is Map && decoded['data'] is List) {
      return (decoded['data'] as List).cast<Map<String, dynamic>>();
    } else if (decoded is Map && decoded['facilities'] is List) {
      return (decoded['facilities'] as List).cast<Map<String, dynamic>>();
    } else if (decoded is Map && decoded['alerts'] is List) {
      return (decoded['alerts'] as List).cast<Map<String, dynamic>>();
    } else if (decoded is Map && decoded['advisories'] is List) {
      return (decoded['advisories'] as List).cast<Map<String, dynamic>>();
    } else if (decoded is Map && decoded['wards'] is List) {
      return (decoded['wards'] as List).cast<Map<String, dynamic>>();
    }
    throw Exception('Unexpected response format from $endpoint');
  }

  // ---------------------------------------------------------------------------
  // Facilities (hospitals)
  // ---------------------------------------------------------------------------
  Future<List<HospitalModel>> fetchFacilities() async {
    final list = await _getList(AppConstants.facilitiesEndpoint);
    return list.map((json) => HospitalModel.fromJson(json)).toList();
  }

  // Keep old name as alias so repositories compile without changes
  Future<List<HospitalModel>> fetchHospitals() => fetchFacilities();

  // ---------------------------------------------------------------------------
  // Alerts
  // ---------------------------------------------------------------------------
  Future<List<AlertModel>> fetchAlerts() async {
    final list = await _getList(AppConstants.alertsEndpoint);
    return list.map((json) => AlertModel.fromJson(json)).toList();
  }

  // ---------------------------------------------------------------------------
  // Advisories
  // ---------------------------------------------------------------------------
  Future<List<AdvisoryModel>> fetchAdvisories() async {
    final list = await _getList(AppConstants.advisoriesEndpoint);
    return list.map((json) => AdvisoryModel.fromJson(json)).toList();
  }

  // ---------------------------------------------------------------------------
  // Wards
  // ---------------------------------------------------------------------------
  Future<List<WardModel>> fetchWards() async {
    final list = await _getList(AppConstants.wardsEndpoint);
    return list.map((json) => WardModel.fromJson(json)).toList();
  }
}
